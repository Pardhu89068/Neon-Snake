const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

const scoreEl = document.getElementById("score");
const highScoreEl = document.getElementById("highScore");
const comboEl = document.getElementById("combo");
const levelEl = document.getElementById("level");
const finalScoreEl = document.getElementById("finalScore");
const levelMeter = document.getElementById("levelMeter");
const missionText = document.getElementById("missionText");
const startOverlay = document.getElementById("startOverlay");
const gameOverOverlay = document.getElementById("gameOverOverlay");

const GRID = 30;
const CELL = canvas.width / GRID;

let snake, direction, nextDirection, food, particles;
let score = 0, highScore = Number(localStorage.getItem("neonSnakeHighScore") || 0);
let level = 1, collected = 0, combo = 1;
let running = false, paused = false, boost = false;
let lastTick = 0, audioCtx = null;

highScoreEl.textContent = pad(highScore);

function pad(n) { return String(n).padStart(6, "0"); }

function init() {
  snake = [
    {x: 15, y: 16}, {x: 14, y: 16}, {x: 13, y: 16},
    {x: 12, y: 16}, {x: 11, y: 16}
  ];
  direction = {x: 1, y: 0};
  nextDirection = {x: 1, y: 0};
  score = 0; level = 1; collected = 0; combo = 1;
  particles = [];
  placeFood();
  updateHUD();
}

function placeFood() {
  do {
    food = {
      x: Math.floor(Math.random() * (GRID - 4)) + 2,
      y: Math.floor(Math.random() * (GRID - 4)) + 2
    };
  } while (snake.some(s => s.x === food.x && s.y === food.y));
}

function startGame() {
  init();
  running = true;
  paused = false;
  startOverlay.classList.add("hidden");
  gameOverOverlay.classList.add("hidden");
  playTone(520, .06);
  requestAnimationFrame(loop);
}

function gameOver() {
  running = false;
  finalScoreEl.textContent = score;
  gameOverOverlay.classList.remove("hidden");
  if (score > highScore) {
    highScore = score;
    localStorage.setItem("neonSnakeHighScore", highScore);
    highScoreEl.textContent = pad(highScore);
  }
  burst(snake[0].x, snake[0].y, 28, "danger");
  playTone(120, .25);
  draw();
}

function loop(time) {
  if (!running) return;
  requestAnimationFrame(loop);

  const base = Math.max(62, 145 - (level - 1) * 8);
  const interval = boost ? base * .52 : base;

  if (!paused && time - lastTick >= interval) {
    lastTick = time;
    tick();
  }
  draw(time);
}

function tick() {
  direction = nextDirection;
  const head = {
    x: snake[0].x + direction.x,
    y: snake[0].y + direction.y
  };

  if (head.x < 0 || head.x >= GRID || head.y < 0 || head.y >= GRID) {
    gameOver(); return;
  }

  if (snake.some((s, i) => i > 0 && s.x === head.x && s.y === head.y)) {
    gameOver(); return;
  }

  snake.unshift(head);

  if (head.x === food.x && head.y === food.y) {
    const gain = 100 * level * combo;
    score += gain;
    collected++;
    combo = Math.min(9, combo + 1);
    burst(food.x, food.y, 20, "core");
    playTone(760 + level * 35, .07);

    if (collected % 5 === 0) {
      level++;
      combo = Math.min(9, combo + 1);
      playTone(1050, .1);
    }
    placeFood();
  } else {
    snake.pop();
    combo = Math.max(1, combo - 0.012);
  }
  updateHUD();
}

function updateHUD() {
  scoreEl.textContent = pad(score);
  highScoreEl.textContent = pad(Math.max(highScore, score));
  comboEl.textContent = "x" + Math.max(1, Math.round(combo));
  levelEl.textContent = String(level).padStart(2, "0");

  const progress = collected % 5;
  levelMeter.style.width = `${progress * 20}%`;
  missionText.textContent = progress === 0
    ? "NEXT LEVEL: 5 CORES"
    : `NEXT LEVEL: ${5 - progress} CORE${5 - progress === 1 ? "" : "S"}`;
}

function setDirection(x, y) {
  if (!running) return;
  if (x === -direction.x && y === -direction.y) return;
  nextDirection = {x, y};
  playTone(250, .025);
}

window.addEventListener("keydown", e => {
  const k = e.key.toLowerCase();
  if (["arrowup","arrowdown","arrowleft","arrowright"," ","w","a","s","d","p","r"].includes(k))
    e.preventDefault();

  if (k === "arrowup" || k === "w") setDirection(0, -1);
  if (k === "arrowdown" || k === "s") setDirection(0, 1);
  if (k === "arrowleft" || k === "a") setDirection(-1, 0);
  if (k === "arrowright" || k === "d") setDirection(1, 0);

  if (k === " ") boost = true;
  if (k === "p" && running) paused = !paused;
  if (k === "r") startGame();
});
window.addEventListener("keyup", e => {
  if (e.key === " ") boost = false;
});

document.getElementById("startBtn").onclick = startGame;
document.getElementById("restartBtn").onclick = startGame;

document.querySelectorAll("[data-dir]").forEach(btn => {
  btn.addEventListener("pointerdown", () => {
    const map = {
      up: [0,-1], down: [0,1], left: [-1,0], right: [1,0]
    };
    setDirection(...map[btn.dataset.dir]);
  });
});

function draw(time = 0) {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawBackground(time);
  drawGrid();
  drawFood(time);
  drawSnake(time);
  drawParticles();
  if (paused && running) drawPause();
}

function drawBackground(time) {
  const g = ctx.createRadialGradient(360, 360, 30, 360, 360, 520);
  g.addColorStop(0, "#07152a");
  g.addColorStop(.55, "#030914");
  g.addColorStop(1, "#01030a");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  ctx.save();
  ctx.globalAlpha = .16;
  for (let i = 0; i < 25; i++) {
    const x = ((i * 131 + time * .008) % 760) - 20;
    const y = (i * 73) % 720;
    ctx.fillStyle = i % 2 ? "#59e8ff" : "#a875ff";
    ctx.fillRect(x, y, 1.5, 1.5);
  }
  ctx.restore();
}

function drawGrid() {
  ctx.save();
  ctx.strokeStyle = "rgba(89,232,255,.065)";
  ctx.lineWidth = 1;
  for (let i = 0; i <= GRID; i++) {
    const p = i * CELL;
    ctx.beginPath(); ctx.moveTo(p, 0); ctx.lineTo(p, canvas.height); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(0, p); ctx.lineTo(canvas.width, p); ctx.stroke();
  }
  ctx.restore();
}

function drawFood(time) {
  const cx = food.x * CELL + CELL / 2;
  const cy = food.y * CELL + CELL / 2;
  const pulse = 1 + Math.sin(time * .008) * .12;

  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(time * .001);
  ctx.shadowBlur = 28;
  ctx.shadowColor = "#ff4edb";
  ctx.strokeStyle = "#ff75e5";
  ctx.lineWidth = 2;

  ctx.beginPath();
  for (let i = 0; i < 4; i++) {
    const a = Math.PI / 4 + i * Math.PI / 2;
    const x = Math.cos(a) * 8 * pulse;
    const y = Math.sin(a) * 8 * pulse;
    i ? ctx.lineTo(x,y) : ctx.moveTo(x,y);
  }
  ctx.closePath();
  ctx.stroke();

  ctx.fillStyle = "#ff4edb";
  ctx.beginPath();
  ctx.arc(0,0,4.5*pulse,0,Math.PI*2);
  ctx.fill();
  ctx.restore();
}

function drawSnake(time) {
  snake.forEach((s, i) => {
    const x = s.x * CELL + 2;
    const y = s.y * CELL + 2;
    const size = CELL - 4;
    const head = i === 0;

    ctx.save();
    ctx.shadowBlur = head ? 24 : 14;
    ctx.shadowColor = head ? "#59e8ff" : "#00a8ff";
    ctx.fillStyle = head ? "#9cf5ff" : `rgba(0, ${180 + Math.min(60, i*3)}, 255, ${Math.max(.35, 1-i*.025)})`;
    ctx.fillRect(x, y, size, size);

    if (head) {
      ctx.fillStyle = "#04101b";
      const eyeX = direction.x !== 0 ? (direction.x > 0 ? x+size-7 : x+5) : x+size/2-2;
      const eyeY = direction.y !== 0 ? (direction.y > 0 ? y+size-7 : y+5) : y+size/2-2;
      ctx.fillRect(eyeX, eyeY, 3, 3);
    }
    ctx.restore();
  });
}

function burst(gx, gy, count, type) {
  const colors = type === "danger" ? ["#ff4edb","#ff657d","#a875ff"] : ["#59e8ff","#67ffbf","#fff"];
  for (let i=0;i<count;i++) {
    const a = Math.random()*Math.PI*2;
    const speed = 1 + Math.random()*4;
    particles.push({
      x: gx*CELL+CELL/2, y: gy*CELL+CELL/2,
      vx: Math.cos(a)*speed, vy: Math.sin(a)*speed,
      life: 1, size: 1+Math.random()*3,
      color: colors[Math.floor(Math.random()*colors.length)]
    });
  }
}

function drawParticles() {
  particles = particles.filter(p => p.life > 0);
  particles.forEach(p => {
    p.x += p.vx; p.y += p.vy; p.life -= .035;
    ctx.save();
    ctx.globalAlpha = p.life;
    ctx.fillStyle = p.color;
    ctx.shadowBlur = 10;
    ctx.shadowColor = p.color;
    ctx.fillRect(p.x, p.y, p.size, p.size);
    ctx.restore();
  });
}

function drawPause() {
  ctx.fillStyle = "rgba(0,0,0,.48)";
  ctx.fillRect(0,0,canvas.width,canvas.height);
  ctx.fillStyle = "#59e8ff";
  ctx.textAlign = "center";
  ctx.font = "700 30px Orbitron";
  ctx.fillText("SYSTEM PAUSED", 360, 340);
  ctx.font = "500 12px Rajdhani";
  ctx.fillStyle = "#91a9bd";
  ctx.fillText("PRESS P TO RESUME", 360, 370);
}

function playTone(freq, duration) {
  try {
    audioCtx ||= new (window.AudioContext || window.webkitAudioContext)();
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.frequency.value = freq;
    osc.type = "sine";
    gain.gain.setValueAtTime(.025, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(.001, audioCtx.currentTime + duration);
    osc.connect(gain); gain.connect(audioCtx.destination);
    osc.start(); osc.stop(audioCtx.currentTime + duration);
  } catch {}
}

init();
draw();