# NEON SNAKE

A futuristic cyber-arena Snake game built with HTML, CSS and JavaScript.

## Run
Open `index.html` in a browser.

## Controls
- Arrow keys / WASD: Move
- Space: Boost
- P: Pause
- R: Restart

High score is saved in browser Local Storage.
